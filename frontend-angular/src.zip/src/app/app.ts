import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, NavigationEnd, RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './components/navbar/navbar';
import { filter } from 'rxjs';
import { SessionService } from './services/session.service'; // Adjust path if needed
import { FooterComponent } from './components/footer/footer'; // 👈 Import it (adjust path as needed)



@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, NavbarComponent,FooterComponent],
template: `
    <app-navbar *ngIf="showNavbar"></app-navbar>
    
    <router-outlet></router-outlet>
    
    <app-footer *ngIf="showNavbar"></app-footer>
  `
})
export class App implements OnInit, OnDestroy {

  showNavbar = true;
  private pageRefreshTimer: ReturnType<typeof setTimeout> | null = null;
  private readonly autoRefreshMs = 45000;

  constructor(
    private router: Router,
    private session: SessionService // 1. Inject SessionService
  ) {
    // Handle Navbar visibility
    this.updateNavbar(this.router.url);
    this.scheduleAutoRefresh(this.router.url);

    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe((e: any) => {
        const url = e.urlAfterRedirects || e.url;
        this.updateNavbar(url);
        this.scheduleAutoRefresh(url);
      });
  }

  ngOnInit() {
    // 2. TRIGGER THE CHECK ON LOAD
    // This calls the API, checks the user, and sets ready = true
    this.session.bootstrap().subscribe({
      next: () => console.log('Session check complete'),
      error: () => console.log('Session check failed (user logged out)')
    });

    
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  if (token && role) {

    if (role === 'user') this.router.navigate(['/user/dashboard']);
    else if (role === 'provider') this.router.navigate(['/provider/dashboard']);
    else if (role === 'admin') this.router.navigate(['/admin/dashboard']);

  }
  }

  ngOnDestroy(): void {
    this.clearAutoRefreshTimer();
  }

  private updateNavbar(url: string) {
    this.showNavbar = !url.startsWith('/auth');
  }

  private scheduleAutoRefresh(url: string): void {
    this.clearAutoRefreshTimer();

    // Skip auth pages and empty urls
    if (!url || url.startsWith('/auth')) return;

    this.pageRefreshTimer = setTimeout(() => {
      this.refreshCurrentRoute();
    }, this.autoRefreshMs);
  }

  private clearAutoRefreshTimer(): void {
    if (this.pageRefreshTimer) {
      clearTimeout(this.pageRefreshTimer);
      this.pageRefreshTimer = null;
    }
  }

  private refreshCurrentRoute(): void {
    const currentUrl = this.router.url;
    if (!currentUrl || currentUrl.startsWith('/auth')) return;

    // Refresh only current route (not whole website/tab)
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigateByUrl(currentUrl);
    });
  }
}
