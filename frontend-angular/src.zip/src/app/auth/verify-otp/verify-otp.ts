import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-verify-otp',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './verify-otp.html'
})
export class VerifyOtpComponent {
  email = '';
  otp = '';
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  verify() {
    this.auth.verifyOtp(this.email, this.otp).subscribe({
      next: () => this.router.navigate(['/auth/reset-password'], {
        queryParams: { email: this.email }
      }),
      error: err => this.error = err.error.message
    });
  }
}
