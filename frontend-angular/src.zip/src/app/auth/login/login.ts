import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth';
import { SessionService } from '../../services/session.service';
import { AuthStateService } from 'src/app/services/auth-state.service';



@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html',
  // styleUrls: ['./login.css']
})
export class LoginComponent {

  email = '';
  password = '';
  error = '';
  menuOpen = false;

  constructor(
    private auth: AuthService,
    private router: Router,
    private session: SessionService,
    private authState: AuthStateService
  ) {}

  login() {
    this.auth.login({ email: this.email, password: this.password }).subscribe({
      next: (res: any) => {
        
        // 🕵️‍♂️ DEBUGGING: Print the entire response to the console
        console.log('🔥🔥 FULL LOGIN RESPONSE:', res);

        // 1. Try to find the token (Handle common names)
        const token = res.token || res.accessToken || res.jwt || res.data?.token;

        if (token) {
          console.log('✅ Saving Token:', token);
          localStorage.setItem('token', token);
        } else {
          console.error('❌ NO TOKEN FOUND in response! Check the console object above.');
        }

        // 2. Save user
        localStorage.setItem('user', JSON.stringify(res));
        // ensure we do not overwrite the detected token with an undefined value
        localStorage.setItem('token', token || localStorage.getItem('token') || '');
        localStorage.setItem('role', res.role);
this.authState.setRole(res.role);
        // 3. Session ready
        this.session.markReady();


         

        // 4. Redirect
        if (res.role === 'admin') this.router.navigateByUrl('/admin/dashboard');
        else if (res.role === 'provider') this.router.navigateByUrl('/provider/home');
        
        else this.router.navigateByUrl('/');
      },
      error: err => {
        console.error(err);
        this.error = err.error?.message || 'Login failed';
      }

      
    });
  }

  goRegister() {
    this.router.navigate(['/auth/register']);
  }

  goForgotPassword() {
    this.router.navigate(['/auth/forgot-password']);
  }


}