import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-verify-account',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './verify-account.html'
})
export class VerifyAccountComponent {
  email = '';
  otp = '';
  error = '';

  constructor(private auth: AuthService, private router: Router) {}

  verify() {
    this.auth.verifyAccount(this.email, this.otp).subscribe({
      next: () => this.router.navigate(['/auth/login']),
      error: err => this.error = err.error.message
    });
  }
}
