import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './reset-password.html'
})
export class ResetPasswordComponent {
 email = '';
otp = '';
password = '';
error = '';
message = '';

  constructor(
    private route: ActivatedRoute,
    private auth: AuthService,
    private router: Router
  ) {
    this.email = this.route.snapshot.queryParams['email'];
  }

reset() {
  if (!this.email || !this.otp || !this.password) {
    this.error = "All fields required";
    return;
  }

  this.auth.resetPassword({
    email: this.email,
    otp: this.otp,
    newPassword: this.password
  }).subscribe({
    next: () => {
      this.message = "Password reset successful";
      this.error = '';
    },
    error: (err) => {
      this.error = err.error?.message || "Reset failed";
    }
  });
}

}
