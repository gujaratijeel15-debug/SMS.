import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpHeaders } from '@angular/common/http';


@Component({
  selector: 'app-book-service',
  templateUrl: './book-service.html',
  styleUrls: ['./book-service.css'],
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule]
})
export class BookServiceComponent implements OnInit {


  isLoggedIn = false;
  // available services
services = [
  {
    name: 'Home Cleaning',
    price: 500,
    image: 'assets/auth/home-2.jpg'
  },
  {
    name: 'Plumbing',
    price: 700,
    image: 'assets/auth/plumbing-2.jpg'
  },
  {
    name: 'Electrical',
    price: 600,
    image: 'assets/auth/electric.png'
  },
  {
    name: 'Appliance Repair',
    price: 900,
    image: 'assets/auth/appliance.png'
  }
];

  selectedService: any = null;
  providers: any[] = [];
  selectedProvider: any = null;
  isLoading = false;
  loadingProviders = false;

  errorMessage = '';
  successMessage = '';
  providerMessage = '';

  constructor(private http: HttpClient, private router: Router) {}

ngOnInit() {
  const token = localStorage.getItem('token');
  this.isLoggedIn = !!token;
}


  // select service card
  selectService(service: any) {
    this.selectedService = service;
    this.selectedProvider = null;
    this.loadProvidersForService(service.name);
  }

  loadProvidersForService(serviceName: string) {
    const token = localStorage.getItem('token');
    if (!token) return;

    this.loadingProviders = true;
    this.providers = [];
    this.providerMessage = '';

    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });

    this.http.get<any>(
      `http://localhost:5000/api/bookings/providers/by-service/${encodeURIComponent(serviceName)}`,
      { headers }
    ).subscribe({
      next: (res) => {
        this.loadingProviders = false;
        const providers = Array.isArray(res) ? res : (res?.providers || []);
        this.providers = providers;
        if (!this.providers.length) {
          this.providerMessage = res?.message || 'Provider not available in your area!';
        }
      },
      error: (err) => {
        this.loadingProviders = false;
        this.providers = [];
        this.providerMessage = err?.error?.message || 'Failed to load providers';
      }
    });
  }

  selectProvider(provider: any) {
    this.selectedProvider = provider;
  }

  getRatingTone(rating: any): string {
    const value = Number(rating) || 0;
    if (value <= 0) return 'rating-none';
    if (value < 2.5) return 'rating-low';
    if (value < 4) return 'rating-mid';
    return 'rating-high';
  }

  getRatingFill(rating: any): string {
    const value = Number(rating) || 0;
    if (value <= 0) return '0%';
    if (value < 2.25) return '25%';
    if (value < 3) return '50%';
    if (value <= 4.5) return '75%';
    return '100%';
  }

confirmBooking() {
  // Validate user is logged in
  if (!this.isLoggedIn) {
    this.router.navigate(['/auth/login']);
    return;
  }

  // Validate service selection
  if (!this.selectedService) {
    this.errorMessage = 'Please select a service';
    return;
  }

  if (!this.selectedProvider) {
    this.errorMessage = 'Please choose a provider';
    return;
  }

  // Reset messages and start loading
  this.isLoading = true;
  this.errorMessage = '';
  this.successMessage = '';

  // Prepare booking data
  const bookingData = {
    serviceName: this.selectedService.name,
    price: this.selectedService.price,
    providerId: this.selectedProvider._id
  };
const token = localStorage.getItem('token');

if (!token) {
  this.router.navigate(['/auth/login']);
  return;
}

const headers = new HttpHeaders({
  Authorization: `Bearer ${token}`
});

this.http.post(
  'http://localhost:5000/api/bookings',
  bookingData,
  { headers }
).subscribe({
  next: () => {
    this.isLoading = false;
    this.successMessage = 'Booking Request Sent! Finding provider...';

    setTimeout(() => {
      this.router.navigate(['/user/bookings']);
    }, 2000);
  },
  error: (err) => {
    this.isLoading = false;
    this.errorMessage = err?.error?.message || 'Booking failed';
    console.log("Full error:", err);
  }
});
}


}
