import { Component, OnInit, inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProviderService } from '../../../../services/provider';


@Component({
  selector: 'app-provider-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './profile.html',
  styleUrls: ['./profile.css'] // use SAME css as user profile
})
export class ProviderProfileComponent implements OnInit {

isAvailable = false;
  providerServices = [
    'Home Cleaning',
    'Plumbing',
    'Electrical',
    'Appliance Repair'
  ];

  profile: any = {};
  editMode = false;
  loading = false;

  defaultAvatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix';
  defaultCover = 'https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?q=80&w=1974&auto=format&fit=crop';

  private platformId = inject(PLATFORM_ID);

  constructor(private providerService: ProviderService) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.loadProfile();
      this.loadAvailability();
    }
  }

  loadProfile() {
    this.providerService.getProfile().subscribe({
      next: data => this.profile = data || {},
      error: () => this.profile = {}
    });
  }

  // image upload
  onFileSelected(event: any, field: 'avatar' | 'cover') {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      this.profile[field] = reader.result;
    };
    reader.readAsDataURL(file);
  }

  save() {
    if (!this.profile.providerService) {
      alert('Please select your service before saving profile.');
      return;
    }

    this.loading = true;

    const updatePayload = {
      name: this.profile.name,
      about: this.profile.about,
      phone: this.profile.phone,
      avatar: this.profile.avatar,
      cover: this.profile.cover,
      providerService: this.profile.providerService
    };

    this.providerService.updateProfile(updatePayload).subscribe({
      next: (updated: any) => {
        this.profile = updated || this.profile;
        const existingUser = JSON.parse(localStorage.getItem('user') || '{}');
        localStorage.setItem('user', JSON.stringify({ ...existingUser, ...this.profile }));
        this.loading = false;
        this.editMode = false;
        alert('Profile saved successfully!');
      },
      error: (err) => {
        this.loading = false;
        console.error(err);
        alert(err?.error?.message || 'Failed to update profile');
      }
    });
  }

  toggleEdit() {
    this.editMode = !this.editMode;
  }

  loadAvailability() {
    this.providerService.getAvailability()
      .subscribe((res: any) => {
        this.isAvailable = res?.isAvailable !== false;
      });
  }

  toggleAvailability() {
    this.providerService.toggleAvailability()
      .subscribe((res: any) => {
        this.isAvailable = res.isAvailable;
      });
  }

  getRatingTone(rating: any): string {
    const value = Number(rating) || 0;
    if (value <= 0) return 'rating-none';
    if (value < 2.5) return 'rating-low';
    if (value < 4) return 'rating-mid';
    return 'rating-high';
  }

  getRatingFill(rating: any): string {
    const value = Number(rating) || 0;
    if (value <= 0) return '0%';
    if (value < 2.25) return '25%';
    if (value < 3) return '50%';
    if (value <= 4.5) return '75%';
    return '100%';
  }
}
