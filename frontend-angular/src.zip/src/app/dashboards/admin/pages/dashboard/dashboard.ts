import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  standalone: true,
  selector: 'app-admin-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.html'

})
export class AdminDashboardComponent implements OnInit {

  stats: any = {};

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('http://localhost:5000/api/admin/stats')
      .subscribe(res => this.stats = res);
  }
}
