import { Routes } from '@angular/router';
import { AdminLayoutComponent } from './layout/admin-layout';

export const ADMIN_ROUTES: Routes = [

  {
    path: '',
    component: AdminLayoutComponent,
    children: [

      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/dashboard/dashboard')
            .then(m => m.AdminDashboardComponent)
      },

      // {
      //   path: 'users',
      //   loadComponent: () =>
      //     import('./pages/users/admin-users')
      //       .then(m => m.AdminUsersComponent)
      // },

      // {
      //   path: 'providers',
      //   loadComponent: () =>
      //     import('./pages/providers/admin-providers')
      //       .then(m => m.AdminProvidersComponent)
      // },

      // {
      //   path: 'bookings',
      //   loadComponent: () =>
      //     import('./pages/bookings/admin-bookings')
      //       .then(m => m.AdminBookingsComponent)
      // },

      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }

    ]
  }

];
