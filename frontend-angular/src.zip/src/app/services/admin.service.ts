import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class AdminService {

  private API = 'http://localhost:5000/api/admin';

  constructor(private http: HttpClient) {}

  getPendingProviders() {
    return this.http.get<any[]>(`${this.API}/pending-providers`, { withCredentials: true });
  }

  approve(id: string) {
    return this.http.put(`${this.API}/approve/${id}`, {}, { withCredentials: true });
  }

  reject(id: string) {
    return this.http.put(`${this.API}/reject/${id}`, {}, { withCredentials: true });
  }
}
