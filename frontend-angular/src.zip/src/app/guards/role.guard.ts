import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class RoleGuard implements CanActivate {

  constructor(private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {

  const role = localStorage.getItem('role');
  const expectedRole = route.data['role'];

  if (!role || role !== expectedRole) {
    this.router.navigate(['/home']);
    return false;
  }

  return true;
}

}
