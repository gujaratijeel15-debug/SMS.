import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  
  // 🔥 DEBUG LOG 1: Is this running?
  console.log(`[Interceptor] Checking request: ${req.url}`);

  const token = localStorage.getItem('token'); 

  if (token) {
    // 🔥 DEBUG LOG 2: Token found
    console.log('[Interceptor] ✅ Token found! Attaching to header.');
    
    const cloned = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}` 
      }
    });
    return next(cloned);
  } else {
    // 🔥 DEBUG LOG 3: No token
    console.warn('[Interceptor] ❌ NO TOKEN found in LocalStorage.');
  }

  return next(req);
};