import { ApplicationConfig } from '@angular/core';
import { provideRouter, withRouterConfig } from '@angular/router';
import { routes } from './app.routes';

import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './core/interceptors/auth.interceptor';


export const appConfig: ApplicationConfig = {
  providers: [
provideRouter(
  routes,
  withRouterConfig({
    onSameUrlNavigation: 'reload'
  })
),
    provideHttpClient(withInterceptors([authInterceptor]))
  ]
};
